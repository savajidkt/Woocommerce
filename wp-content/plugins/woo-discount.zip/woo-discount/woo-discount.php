<?php
/**
 * Woo Discount
 *
 * @package       WOODISCOUN
 * @author        Savji Rathod
 * @version       1.0
 *
 * @wordpress-plugin
 * Plugin Name:   Woo Discount
 * Plugin URI:    savajirathod.com
 * Description:   This Plugin is practical test
 * Version:       1.0
 * Author:        Savji Rathod
 * Author URI:    savajirathod.com
 * Text Domain:   woo-discount
 * Domain Path:   /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

// Include your custom code here.
